/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ca.sheridancollege.project;

import java.util.Scanner;

/**
 *
 * @author patel
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner k= new Scanner(System.in);
        String name[]= new String[4];
        int ID[]={1,2,3,4};
        int ie=1;
        // TODO code application logic here
        System.out.println("Welcome to KachuFul");
        System.out.println("Enter name of Player 1 and is your ID is:"+ID[0]);
         name[0]=k.nextLine();
          System.out.println("Enter name of Player 2 and is your ID is:"+ID[1]);
         name[1]=k.nextLine();
           System.out.println("Enter name of Player 3 and is your ID is:"+ID[2]);
         name[2]=k.nextLine();
         System.out.println("Enter name of Player 4 and is your ID is:"+ID[3]);
         name[3]=k.nextLine();
         Player p= new Player();
         Game g= new Game();
         p.setName(name);
         p.setID(ID);
         int c=0;
         int pre[]= new int[4];
         
         do{
             int r=0;
            int round=1;
             int po1[]= new int[ie];
             int po2[]= new int[ie];
             int po3[]= new int[ie];
             int po4[]= new int[ie];
             p.tcrad();
             System.out.println("Trump card of this Group:"+p.getT());
             System.out.println("This Round is gonna be of "+ie+"Cards");
            //dg GroupOfCards g= new  GroupOfCards();
             
             g.generate(ie);
             System.out.println("Now Game Starts.........");
             do{
             if(r==0){
             do{
             System.out.println("To see card of player 1 enter 1");
             c=k.nextInt();
             g.showcard1(c);
             }while(c!=1);
             c=0;
             System.out.println("Enter your prediction:");
             pre[0]=k.nextInt();
             do{
             System.out.println("To see card of player 2 enter 1");
             c=k.nextInt();
             g.showcard2(c);
             }while(c!=1);
             c=0;
              System.out.println("Enter your prediction:");
             pre[1]=k.nextInt();
             do{
             System.out.println("To see card of player 3 enter 1");
             c=k.nextInt();
             g.showcard3(c);
             }while(c!=1);
             c=0;
              System.out.println("Enter your prediction:");
             pre[2]=k.nextInt();
             do{
             System.out.println("To see card of player 4 enter 1");
             c=k.nextInt();
             g.showcard4(c);
             }while(c!=1);
             c=0;
              System.out.println("Enter your prediction:");
             pre[3]=k.nextInt();
             p.setP(pre);
             do{
             System.out.println("To select the card of player 1 enter 1");
             c=k.nextInt();
             g.showcard1(c);
             System.out.println("Enter the index of the card you want to play consider first to start form 0: ");
             po1[r]=k.nextInt();
             }while(c!=1 && r<=ie && r>=0);
             c=0;
             do{
             System.out.println("To select the card of player 2 enter 1");
             c=k.nextInt();
             g.showcard2(c);
             System.out.println("Enter the index of the card you want to play consider first to start form 0: ");
             po2[r]=k.nextInt();
             }while(c!=1 && r<=ie && r>=0);
             c=0;
             do{
             System.out.println("To select the card of player 3 enter 1");
             c=k.nextInt();
             g.showcard3(c);
             System.out.println("Enter the index of the card you want to play consider first to start form 0: ");
             po3[r]=k.nextInt();
             }while(c!=1 && r<=ie && r>=0);
             c=0;
              do{
             System.out.println("To select the card of player 4 enter 1");
             c=k.nextInt();
             g.showcard4(c);
             System.out.println("Enter the index of the card you want to play consider first to start form 0: ");
             po4[r]=k.nextInt();
             }while(c!=1 && r<=ie && r>=0);
             c=0;
             
              g.play(po1[r],po2[r],po3[r],po4[r],ie);
           //  g.play(0, 0, 0,0);
          
           //g.play(po1[r],po2[r],po3[r],po4[r]);
               g.show(); 
             //g.check();
           r++;
             }
             
             //-------------------------------------
             else{
                 int p1c=0;
                 int p2c=0;
                 int p3c=0;
                 int p4c=0;
                do{
             System.out.println("To see card of player 1 enter 1");
             c=k.nextInt();
             g.showcard1(c);
             }while(c!=1);
             c=0;
             System.out.println("Enter your prediction:");
             pre[0]=k.nextInt();
             do{
             System.out.println("To see card of player 2 enter 1");
             c=k.nextInt();
             g.showcard2(c);
             }while(c!=1);
             c=0;
              System.out.println("Enter your prediction:");
             pre[1]=k.nextInt();
             do{
             System.out.println("To see card of player 3 enter 1");
             c=k.nextInt();
             g.showcard3(c);
             }while(c!=1);
             c=0;
              System.out.println("Enter your prediction:");
             pre[2]=k.nextInt();
             do{
             System.out.println("To see card of player 4 enter 1");
             c=k.nextInt();
             g.showcard4(c);
             }while(c!=1);
             c=0;
              System.out.println("Enter your prediction:");
             pre[3]=k.nextInt();
             p.setP(pre);
             do{
                 int cc1=0;
                 int ccc1=0;
             System.out.println("To select the card of player 1 enter 1");
             c=k.nextInt();
             g.showcard1(c);
             do{
             System.out.println("Enter the index of the card you want to play consider first to start form 0: ");
            p1c=k.nextInt();
             
              if(po1[ccc1]==p1c){
                     cc1=1;
                     po1[r]=p1c;
                 }
              ccc1++;
             }while(cc1==1);
             }while(c!=1 && p1c<=ie && p1c>=0);
             c=0;
             do{
                 int cc2=0;
                 int ccc2=0;
             System.out.println("To select the card of player 2 enter 1");
             c=k.nextInt();
             g.showcard2(c);
              do{
             System.out.println("Enter the index of the card you want to play consider first to start form 0: ");
            p1c=k.nextInt();
             
              if(po1[ccc2]==p1c){
                     cc2=1;
                      po2[r]=p2c;
                 }
              ccc2++;
             }while(cc2==1);
             }while(c!=1 && p2c<=ie && p2c>=0);
             c=0;
             do{
                 int cc3=0;
                 int ccc3=0;
             System.out.println("To select the card of player 3 enter 1");
             c=k.nextInt();
             g.showcard3(c);
             do{
             System.out.println("Enter the index of the card you want to play consider first to start form 0: ");
            p1c=k.nextInt();
             
              if(po1[ccc3]==p1c){
                     cc3=1;
                      po3[r]=p3c;
                 }
              ccc3++;
             }while(cc3==1);
             }while(c!=1 && p3c<=ie && p3c>=0);
             c=0;
              do{
                  int cc4=0;
                 int ccc4=0;
             System.out.println("To select the card of player 4 enter 1");
             c=k.nextInt();
             g.showcard4(c);
             do{
             System.out.println("Enter the index of the card you want to play consider first to start form 0: ");
            p1c=k.nextInt();
             
              if(po1[ccc4]==p1c){
                     cc4=1;
                      po4[r]=p4c;
                 }
              ccc4++;
             }while(cc4==1);
             }while(c!=1 && p4c<=ie && p4c>=0);
             c=0;
             
              g.play(po1[r],po2[r],po3[r],po4[r],ie);
              r++;
             }
           
             }while(round<ie);    
          ie++;
         }while(ie<3);
         
    }
    
 }
             
