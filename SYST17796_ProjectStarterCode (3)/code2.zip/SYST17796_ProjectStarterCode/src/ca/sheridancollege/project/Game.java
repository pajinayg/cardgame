/**
 * SYST 17796 Project Base code.
 * Students can modify and extend to implement their game.
 * Add your name as an author and the date!
 */
package ca.sheridancollege.project;

import ca.sheridancollege.project.Card.Suit;
import ca.sheridancollege.project.Card.Value;
import java.util.ArrayList;
import java.util.*;

/**
 * The class that models your game. You should create a more specific child of this class and instantiate the methods
 * given.
 *
 * @author dancye
 * @author Paul Bonenfant Jan 2020
 */
public  class Game extends GroupOfCards {
    private Suit presidence;
    private Value presidence1;
public void play(Suit S,int i,int j,int k,int l){
    if(deck1[i].getS()==deck2[j].getS())
    {
       if(deck1[i].getV() != deck2[j].getV())
       {
           
       }
        
    }
}

	

}//end class
